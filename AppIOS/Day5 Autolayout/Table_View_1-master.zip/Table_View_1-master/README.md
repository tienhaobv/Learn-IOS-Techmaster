#  Edit, Add, Delete dữ liệu trong Table View:
1- Sử dụng photo library

