//
//  Diary.swift
//  iOSControl
//
//  Created by Taof on 4/20/19.
//  Copyright © 2019 Tào Quỳnh . All rights reserved.
//

import Foundation

struct Post {
    var title: String
    var feel: String
}
