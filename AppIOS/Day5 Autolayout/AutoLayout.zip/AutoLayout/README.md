# Danh sách các Autolayout framework


## Sử dụng pod để cài đặt thư viện ngoài

##  Stevia hỗ trợ layout dễ hơn

## 
https://github.com/freshOS/Stevia
https://github.com/marty-suzuki/MisterFusion
http://snapkit.io/docs/
https://github.com/wordlessj/Bamboo
https://github.com/onmyway133/Anchors

Nhiều tool rất hay và tiện dụng
http://freshos.org/
