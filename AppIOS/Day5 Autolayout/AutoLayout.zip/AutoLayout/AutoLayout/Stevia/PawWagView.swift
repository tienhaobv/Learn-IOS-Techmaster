//
//  PawWagView.swift
//  DogDonation
//
//  Created by Techmaster on 3/27/19.
//  Copyright © 2019 Techmaster. All rights reserved.
//

import UIKit
import Stevia


class PawWagView: UIView {
 
    
    convenience init() {
        self.init(frame:CGRect.zero)
        print("H")
    }
    
    
    
    
}
