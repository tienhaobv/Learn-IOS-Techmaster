//
//  MainScreen.swift
//  login_with_server
//
//  Created by Cuong  Pham on 9/17/19.
//  Copyright © 2019 Cuong  Pham. All rights reserved.
//

import UIKit
import Stevia

class MainScreen: UIViewController {
    private let service = UserService()
    private var dataArray : Array<User> = []
    private lazy var mainTableView : UITableView = UITableView()

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableView()
        view.backgroundColor = .lightGray
        //self.mainTableView.reloadData()
    }
    
    private func setUpTableView(){
        view.sv(mainTableView)
        
        navigationItem.title = "All User"
        navigationItem.rightBarButtonItem = UIBarButtonItem.init(barButtonSystemItem: .add, target: self, action: #selector(onTapAdd))
        
        mainTableView.Top == view.safeAreaLayoutGuide.Top
        mainTableView.centerHorizontally().width(100%).Bottom == view.safeAreaLayoutGuide.Bottom
        
        mainTableView.delegate = self
        mainTableView.dataSource = self
        mainTableView.register(UserCell.self, forCellReuseIdentifier: "User")
        
        mainTableView.bounces = false
        mainTableView.tableFooterView = UIView()
        service.delegate = self
        
    }
    
    @objc func onTapAdd(){
        let nextVC = DetailScreen()
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        DispatchQueue.main.async {
            self.service.loadUser()
            self.mainTableView.reloadData()
        }
        
    }
}


extension MainScreen : UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = mainTableView.dequeueReusableCell(withIdentifier: "User", for: indexPath) as? UserCell else {
            fatalError("fail")
        }
        cell.emailLabel.text = dataArray[indexPath.row].email
        cell.nameLabel.text = dataArray[indexPath.row].fullName
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let nextVC = DetailScreen()
        nextVC.emailTextField.text = self.dataArray[indexPath.row].email
        nextVC.nameTextField.text = self.dataArray[indexPath.row].fullName
        nextVC.passTextField.text = self.dataArray[indexPath.row].password
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
}

extension MainScreen : UserServiceDelegate {
    func loadUserSuccess(data: [User]) {
        self.dataArray = data
        self.mainTableView.reloadData()
    }
    
    func loadUserFail(error: Error) {
        print(error)
    }
}
