//
//  Foody.swift
//  UICollectionViewBasic
//
//  Created by Taof on 8/26/19.
//  Copyright © 2019 Taof. All rights reserved.
//

import Foundation

// model Foody
struct Foody {
    let imageName: String
    let name: String
    let description: String
}
