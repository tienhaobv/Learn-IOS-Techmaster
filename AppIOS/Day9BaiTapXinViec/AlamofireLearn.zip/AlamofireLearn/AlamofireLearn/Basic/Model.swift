//
//  Model.swift
//  AlamofireLearn
//
//  Created by Techmaster on 4/18/19.
//  Copyright © 2019 Techmaster. All rights reserved.
//

import Foundation

struct Post {
    var id: String
    var body: String
    var title: String
    var userID: Int
}
