#  Chú ý khi chạy ứng dụng này

1. Cần có Sanic web framework

