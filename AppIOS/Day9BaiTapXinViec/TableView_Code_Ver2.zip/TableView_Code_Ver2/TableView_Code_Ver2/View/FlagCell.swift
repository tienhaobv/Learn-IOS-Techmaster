
import UIKit
import Stevia

protocol FlagCellDelegate {
    func didTapClickButton(_flag : NationalFlag)
}

class FlagCell: UITableViewCell{
    var flag : NationalFlag!
    var delegate : FlagCellDelegate?
    //sử dụng biến này để gán
    //var flag : NationalFlag!
    
    //khai báo thành phần có trong cell
    lazy var flagNational : UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    //khai báo thành phần có trong cell
    lazy var nationalName : UILabel = {
        let label = UILabel()
        label.textColor = .red
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.sizeToFit()
        return label
    }()
    //khai báo thành phần có trong cell
    lazy var capitalName : UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 18)
        label.sizeToFit()
        return label
    }()
    // cho nay neu de "var" thi ko chay, neu de "lazy var' lai chay
    lazy var button : UIButton = {
        let button = UIButton()
        button.setTitle("Click me", for: .normal)
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
        button.isUserInteractionEnabled = true
        button.addTarget(self, action: #selector(onTap), for: .touchUpInside)
        return button
    }()
    
    @objc func onTap(){
        self.delegate?.didTapClickButton(_flag: flag)
    }
    
    //autolayout cho các thành phần trong cell
    fileprivate func autoLayoutForCell(){
        self.sv(flagNational, nationalName, capitalName, button)
        
        flagNational.centerVertically().width(50).height(80%)
        flagNational.Leading == self.Leading + 20
        
        nationalName.Top == flagNational.Top
        nationalName.Leading == flagNational.Trailing + 20
        
        capitalName.Bottom == flagNational.Bottom
        capitalName.Leading == nationalName.Leading
        
        button.width(100).height(40).centerVertically()
        button.Trailing == self.Trailing - 20
    }
    
    //gán dữ liệu vào các thành phần trong cell
    func configureCell(flag: NationalFlag){
        self.flag = flag
        flagNational.image = UIImage(named: flag.flag)
        nationalName.text = flag.nationalName
        capitalName.text = flag.capitalName
    }

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        autoLayoutForCell()
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
