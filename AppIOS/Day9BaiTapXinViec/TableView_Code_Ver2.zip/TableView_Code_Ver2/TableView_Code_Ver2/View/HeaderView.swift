//
//  HeaderView.swift
//  TableView_Code_Ver2
//
//  Created by Cuong  Pham on 8/12/19.
//  Copyright © 2019 Cuong  Pham. All rights reserved.
//

import UIKit
import Stevia

class HeaderView: UIView {
    
    lazy var headerLabel : UILabel = {
        let label = UILabel()
        label.text = "Demo Flag"
        label.textColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
        label.sizeToFit()
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = #colorLiteral(red: 0.501960814, green: 0.501960814, blue: 0.501960814, alpha: 1)
        autoLayoutHeaderLabel()
    }
    
    fileprivate func autoLayoutHeaderLabel(){
        self.sv(headerLabel)
        headerLabel.centerHorizontally()
        headerLabel.Top == self.Top + 10
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
