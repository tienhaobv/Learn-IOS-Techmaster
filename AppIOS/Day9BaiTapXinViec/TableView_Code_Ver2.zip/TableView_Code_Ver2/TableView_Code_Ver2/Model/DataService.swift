//
//  DataService.swift
//  TableView_Code_Ver2
//
//  Created by Cuong  Pham on 8/12/19.
//  Copyright © 2019 Cuong  Pham. All rights reserved.
//

import Foundation

protocol DataServieDelegate : class {
    func nationalFlagLoaded()
}

class DataService {
    
    //1-khai báo biến instance như 1 thằng trung gian để các lớp khác có thể truy cập vào các thuộc tính, phương thức của ĐataService
    static var instance : DataService = DataService()
    
    //2-khai báo mảng lưu dữ liệu
    var flagArray : Array<NationalFlag> = []
    
    //3- tạo protocol và delegate
    weak var delegate : DataServieDelegate?
    
    func loadNationalFlagData() -> [NationalFlag]{
        flagArray.append(NationalFlag(flag: "1", nationalName: "England", capitalName: "London"))
        flagArray.append(NationalFlag(flag: "2", nationalName: "Brazil", capitalName: "Rio de Janeiro"))
        flagArray.append(NationalFlag(flag: "3", nationalName: "France", capitalName: "Paris"))
        flagArray.append(NationalFlag(flag: "", nationalName: "", capitalName: "Saigon"))
        flagArray.append(NationalFlag(flag: "5", nationalName: "China", capitalName: "Beijing"))
        flagArray.append(NationalFlag(flag: "6", nationalName: "Republic of Korea", capitalName: "Seoul"))
        flagArray.append(NationalFlag(flag: "7", nationalName: "Belgium", capitalName: "Bruxelles"))
        flagArray.append(NationalFlag(flag: "8", nationalName: "Germany", capitalName: "Berlin"))
        flagArray.append(NationalFlag(flag: "9", nationalName: "Japan", capitalName: "Tokyo"))
        flagArray.append(NationalFlag(flag: "10", nationalName: "Italy", capitalName: "Rome"))
        
        delegate?.nationalFlagLoaded()
        return flagArray
    }
}
