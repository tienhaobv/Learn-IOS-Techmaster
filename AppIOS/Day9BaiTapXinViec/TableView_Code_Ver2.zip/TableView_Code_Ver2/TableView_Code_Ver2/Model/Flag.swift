//
//  Flag.swift
//  TableView_Code_Ver2
//
//  Created by Cuong  Pham on 8/12/19.
//  Copyright © 2019 Cuong  Pham. All rights reserved.
//

import Foundation

struct NationalFlag {
    private var _flag : String!
    private var _nationalName : String!
    private var _capitalName : String!
    
    var flag : String {
        return _flag
    }
    
    var nationalName : String {
        return _nationalName
    }
    
    var capitalName : String {
        return _capitalName
    }
    
    init(flag : String, nationalName : String, capitalName : String){
        self._flag = flag
        self._nationalName = nationalName
        self._capitalName = capitalName
        
    }
}
