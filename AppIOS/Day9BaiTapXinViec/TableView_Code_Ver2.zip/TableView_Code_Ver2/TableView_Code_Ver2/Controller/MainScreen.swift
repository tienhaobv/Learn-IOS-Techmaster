//
//  MainScreen.swift
//  TableView_Code_Ver2
//
//  Created by Cuong  Pham on 8/12/19.
//  Copyright © 2019 Cuong  Pham. All rights reserved.
//

import UIKit
import Stevia
class MainScreen: UIViewController, DataServieDelegate {

    var ds : DataService = DataService.instance

    var headerView : HeaderView = HeaderView()
    var tableView : FlagTableView = FlagTableView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red
        autoLayoutHeaderView()
        autoLayoutTableView()
        
        ds.delegate = self
        //load dữ liệu lên
        print(ds.loadNationalFlagData())
       // print(ds.flagArray)
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.register(FlagCell.self, forCellReuseIdentifier: "Cell")
    }
    
    fileprivate func autoLayoutHeaderView() {
        view.sv(headerView)
        headerView.centerHorizontally().height(50)
        headerView.Width == view.Width
        headerView.Top == view.safeAreaLayoutGuide.Top
    }
    
    fileprivate func autoLayoutTableView() {
        view.sv(tableView)
        tableView.Top == headerView.Bottom
        tableView.Width == view.Width
        tableView.centerHorizontally()
        tableView.Bottom == view.safeAreaLayoutGuide.Bottom
    }
    
    //hàm này kế thừa từ delegate
    func nationalFlagLoaded() {
        print("Loaded data")
    }
}

extension MainScreen : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ds.flagArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as? FlagCell else {
            fatalError("Fail")
        }
        cell.delegate = self
        cell.configureCell(flag: ds.flagArray[indexPath.row])
       
       // cell.name = ds.flagArray[indexPath.row].nationalName
        cell.flag = ds.flagArray[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}


extension MainScreen : FlagCellDelegate {
    func didTapClickButton(_flag: NationalFlag) {
        print("\(_flag.capitalName) and \(_flag.nationalName) is tapped")
    }
}
