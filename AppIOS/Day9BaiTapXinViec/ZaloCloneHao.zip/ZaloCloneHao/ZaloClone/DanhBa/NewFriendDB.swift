//
//  NewFriendDB.swift
//  ZaloClone
//
//  Created by Ba Thoc on 9/4/19.
//  Copyright © 2019 Techmaster. All rights reserved.
//

import Foundation
import UIKit

class NewfirendDB {
    var imgAvartar: UIImage
    var name: String
    
    init(_imgAvartar: UIImage, _name: String) {
        imgAvartar = _imgAvartar
        name = _name
    }
    
}
