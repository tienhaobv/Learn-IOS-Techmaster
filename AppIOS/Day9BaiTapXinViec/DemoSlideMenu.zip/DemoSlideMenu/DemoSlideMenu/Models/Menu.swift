//
//  Menu.swift
//  AppQuiz
//
//  Created by Taof on 8/28/19.
//  Copyright © 2019 Taof. All rights reserved.
//

import Foundation

struct Menu {
    let icon: String
    let name: String
}
