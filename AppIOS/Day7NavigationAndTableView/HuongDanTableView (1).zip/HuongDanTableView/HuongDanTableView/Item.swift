//
//  Item.swift
//  HuongDanTableView
//
//  Created by Taof on 8/22/19.
//  Copyright © 2019 Taof. All rights reserved.
//

import Foundation
import UIKit

struct Item {
    var name: String
    var address: String
    var photo: UIImage?
}
