#  Góp ý của thầy Cường

1. Lập trình game cần phải hiểu về hướng đối tượng. Bởi vì hướng đối tượng sẽ giúp chúng ta quản lý logic tương tác giữa các nhân vật hoặc sprite tốt hơn
2. Hãy cố gắng đơn giản hóa vấn đề
3. Viết comment và to do list ra chi tiết rồi hãy code
4. Chia nhỏ các hàm ra

