#  Chiến tranh giữa các vì sao

## Bước tiến hành

1. Vẽ một spaceship hiện thị nó ở trung điểm cạnh đáy màn hình
2. Gắn vào TapGestureRecognizer đối tượng SpaceShip
3.

Chú ý lỗi memory leakig khi Menu > Profile > Leak

![](ProfileLeak.jpg)