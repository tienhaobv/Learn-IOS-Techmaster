//
//  Chess.swift
//  ChessBoard
//
//  Created by Techmaster on 5/27/19.
//  Copyright © 2019 Techmaster. All rights reserved.
//

import UIKit
//Khai báo kiểu enum định nghĩa kiểu quân cờ
//Khai báo kiểu struct Position {x: Int, y: Int}
class Chess: UIImageView {
    //type: ChessType
    //isBlack: true - false
    //currentPosition: Position
    
    
    //if valid move return true
    //else return false
    func move(newPosition: Position)->Bool {
        
    }
   
}
