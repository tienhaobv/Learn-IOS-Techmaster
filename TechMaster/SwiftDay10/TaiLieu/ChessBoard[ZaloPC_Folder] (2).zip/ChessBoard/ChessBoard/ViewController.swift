//
//  ViewController.swift
//  ChessBoard
//
//  Created by Techmaster on 3/18/19.
//  Copyright © 2019 Techmaster. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var screenWidth: CGFloat = 0
    var screenHeight: CGFloat = 0
    var squareWidth: CGFloat = 0
    var margin: CGFloat = 4.0
    var timer: Timer!
    var ccwcounter: Int = 7
    var cwcounter: Int = 0
    var watch: Int = 1
    var image: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpControl()
        timer = Timer.scheduledTimer(timeInterval: 0.5,
                                     target: self,
                                     selector: #selector(gameLoop),
                                     userInfo: nil,
                                     repeats:  true)
    }
    @objc func gameLoop() {
        if watch > 4 {
            timer.invalidate()
            print("finish")
        }
        //clockwise()
        //counterclockwise()
        butterfly()
    }
    
    func setUpControl() {
        screenWidth = self.view.bounds.width
        screenHeight = self.view.bounds.height
        squareWidth = (self.view.bounds.width - margin * 2.0) / 8.0
        self.view.backgroundColor = UIColor(red: 0.8, green: 0.8, blue: 0.8, alpha: 1.0)
        
        for row in 0..<8 {
            for col in 0..<8 {
                let isWhiteSquare = (row + col) % 2 == 1 ? true: false
                drawSquare(isWhite: isWhiteSquare, width: squareWidth, row: row, col: col)
            }
        }
        placeQueen(isWhite: true, row: 0, col: 0)
    }
    
   
    func drawSquare(isWhite: Bool, width: CGFloat, row: Int, col: Int) {
        //Hàm có thể định nghĩa bên trong hàm khác
        func computePositionOfSquare(row: Int, col: Int, squareWidth: CGFloat) -> CGRect {
            return CGRect(x: margin + CGFloat(col) * squareWidth, y: 100 + CGFloat(row) * squareWidth, width: squareWidth, height: squareWidth)
        }
        
        
        let square = UIView(frame: computePositionOfSquare(row: row, col: col, squareWidth: width))
        square.backgroundColor = isWhite ? UIColor.white : UIColor.black
        self.view.addSubview(square)
    }
    
    func placeQueen(isWhite: Bool, row: Int, col: Int) {
        let queen = UIImageView(image: UIImage(named: "queen"))
        queen.frame = CGRect(x: margin + CGFloat(col) * squareWidth, y: 100 + CGFloat(row) * squareWidth, width: squareWidth, height: squareWidth)
        queen.contentMode = .scaleAspectFit
        image = queen
        self.view.addSubview(queen)
    }
    
    func deleteQueen() {
        image.removeFromSuperview()
    }
    
    func lane1(_ counter: Int) {
        deleteQueen()
        placeQueen(isWhite: true, row: 0, col: 0 + counter)
    }
    func lane2(_ counter: Int) {
        deleteQueen()
        placeQueen(isWhite: true, row: 0 + counter, col: 7)
    }
    func lane3(_ counter: Int) {
        deleteQueen()
        placeQueen(isWhite: true, row: 7, col: 7 - counter)
    }
    func lane4(_ counter: Int) {
        deleteQueen()
        placeQueen(isWhite: true, row: 7 - counter, col: 0)
    }
    func diag1(_ counter: Int) {
        deleteQueen()
        placeQueen(isWhite: true, row: 0 + counter, col: 0 + counter)
    }
    func diag2(_ counter: Int) {
        deleteQueen()
        placeQueen(isWhite: true, row: 0 + counter, col: 7 - counter)
    }
    func lane2ver2(_ counter: Int) {
        deleteQueen()
        placeQueen(isWhite: true, row: 7 - counter, col: 7)
    }
    
    func clockwise() {
        if cwcounter >= 8 { cwcounter = 0
            watch += 1 }
        if watch == 1 {
            lane1(cwcounter) }
        else if watch == 2 {
            lane2(cwcounter) }
        else if watch == 3 {
            lane3(cwcounter) }
        else if watch == 4 {
            lane4(cwcounter) }
        cwcounter += 1
    }
    
    func counterclockwise() {
        if ccwcounter <= -1 { ccwcounter = 7
            watch += 1 }
        if watch == 1 {
            lane4(ccwcounter) }
        else if watch == 2 {
            lane3(ccwcounter) }
        else if watch == 3 {
            lane2(ccwcounter) }
        else if watch == 4 {
            lane1(ccwcounter) }
        ccwcounter -= 1
    }
    
    func butterfly() {
        if cwcounter >= 8 { cwcounter = 0
            watch += 1 }
        if watch == 1 {
            diag1(cwcounter) }
        else if watch == 2 {
            lane2ver2(cwcounter) }
        else if watch == 3 {
            diag2(cwcounter) }
        else if watch == 4 {
            lane4(cwcounter) }
        cwcounter += 1
    }
}

