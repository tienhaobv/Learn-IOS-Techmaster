//
//  MainScreen.swift
//  Tetris
//
//  Created by apple on 6/13/19.
//  Copyright © 2019 Hào. All rights reserved.
//

import UIKit

class MainScreen: UIViewController {
    
    var arrayHint = [[Int]]()
    var columnHint = 10
    var rowHint = 22
    var margin : CGFloat = 2.0
    var blockHint = [[BlockHint]]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .black
        createBlockHint()
    }
    
    func createBlockHint() {
        let sizeBlockHint = CGFloat.minimum((view.bounds.height - 60 - CGFloat(rowHint+1) * margin) / CGFloat(rowHint), (view.bounds.height - CGFloat(columnHint+1) * margin) / CGFloat(columnHint))
        let maginWidth = view.bounds.width - (sizeBlockHint * CGFloat(columnHint) + CGFloat(columnHint+1) * margin)
        let maginHeight = view.bounds.height - 60 - (sizeBlockHint * CGFloat(rowHint) + CGFloat(rowHint+1) * margin)
        print(maginWidth)
        print(maginHeight)
        let maxMagin = max(maginWidth, maginHeight)
        var isWidth : Bool = false
        print(maxMagin)
        if maginWidth == maxMagin {
            isWidth = true
        }
        print(isWidth)
        
        for i in 0..<rowHint {
            var blockHintRow = [BlockHint]()
            for j in 0..<columnHint {
                var subBlockHint = BlockHint()
                if isWidth {
                    subBlockHint.frame = CGRect(x: maxMagin/2 + margin * CGFloat(j + 1) + sizeBlockHint * CGFloat(j),
                                                y: 40.0 + margin * CGFloat(i + 1) + sizeBlockHint * CGFloat(i),
                                                width: sizeBlockHint,
                                                height: sizeBlockHint)
                }
                else {
                    subBlockHint.frame = CGRect(x: margin * CGFloat(j + 1) + sizeBlockHint * CGFloat(j),
                                                y: maxMagin + 40.0 + margin * CGFloat(i + 1) + sizeBlockHint * CGFloat(i),
                                                width: sizeBlockHint,
                                                height: sizeBlockHint)
                }
                //subBlockHint.backgroundColor = .gray
                //subBlockHint.alpha = 40
                subBlockHint.type = 2
                view.addSubview(subBlockHint)
                blockHintRow.append(subBlockHint)
            }
            blockHint.append(blockHintRow)
        }
        
    }
    

    

}
