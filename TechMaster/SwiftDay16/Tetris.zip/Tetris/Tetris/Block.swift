//
//  Block.swift
//  Tetris
//
//  Created by apple on 6/13/19.
//  Copyright © 2019 Hào. All rights reserved.
//

import UIKit

class Block: UIView {

    convenience init() {
        self.init(frame: CGRect.zero)
        self.alpha = 100
    }

}
