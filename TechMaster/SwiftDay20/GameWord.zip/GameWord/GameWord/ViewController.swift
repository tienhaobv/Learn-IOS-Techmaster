//
//  ViewController.swift
//  GameWord
//
//  Created by Tung on 7/3/19.
//  Copyright © 2019 Tung. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        drawBoard()
    }
    func drawBoard(){
        let width = view.frame.width / 7
        
        for i in 0..<7 {
            for j in 0...7{
                let cellView = UIView()
                
                cellView.frame = CGRect(x: CGFloat(j) * width, y: CGFloat(i) * width, width: width, height: width)
                cellView.layer.borderWidth = 0.5
                cellView.layer.borderColor = UIColor.black.cgColor
         
                view.addSubview(cellView)
               
            }
        }
    }
    


}

