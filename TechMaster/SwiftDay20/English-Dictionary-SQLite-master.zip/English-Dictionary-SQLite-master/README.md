# English-Dictionary-SQLite
English Dictionary in SQLite 

I have compiled this SQLite database consisting more than 70k words! If you are wondering what is SQLite and what are the advantages of SQLite, it does not need a SQL Server! 

More information can be found at https://ayeshjayasekara.wordpress.com/blog/

Share & Shine!
