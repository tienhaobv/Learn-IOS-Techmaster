#  Game Memory

## Ý tưởng
 Làm một game với một mảng các thẻ bài trên màn hình, nhiệm vụ của người chơi là tìm hết các cặp thẻ bải trong thời gian là 30s

## Chi tiết
- Trang Home để chọn các chế độ chơi
    + Tên Game
    + Các chế độ chơi
        - Easy
        - Medium
        - Hard
    + Hiệu ứng
- Trang GamePlay
    + Thanh tính thời gian
        - Biến timer để chạy thời gian
        - Hình ảnh thanh tính thời gian giảm dần
        - Bao bên ngoài và icon biểu thị thanh tính thời gian
    + Các thẻ bài
        - Có ID để định danh các thẻ bài
        - Có type để định kiểu và so sánh đúng sai
    + Biến hàng, cột và các biến để check đúng sai của các cặp thẻ bài
    + Hàm random sao cho các thẻ bài có tần suất tương đương
    + Các biến âm thanh
- Kết thúc game
    + Hình ảnh thể hiện Win hoặc Lost
    + Buttom Replay để chơi lại
    + Âm thanh thắng thua tương ứng
    

